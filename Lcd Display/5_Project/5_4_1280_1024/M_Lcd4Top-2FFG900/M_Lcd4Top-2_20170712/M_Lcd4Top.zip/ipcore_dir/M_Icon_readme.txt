The following files were generated for 'M_Icon' in directory
D:\Temp\M_Lcd4Top_0618\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * M_Icon.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * M_Icon.constraints/M_Icon.ucf
   * M_Icon.constraints/M_Icon.xdc
   * M_Icon.ngc
   * M_Icon.ucf
   * M_Icon.vhd
   * M_Icon.vho
   * M_Icon.xdc
   * M_Icon_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * M_Icon.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * M_Icon.gise
   * M_Icon.xise
   * _xmsgs/pn_parser.xmsgs

Deliver Readme:
   Readme file for the IP.

   * M_Icon_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * M_Icon_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

