The following files were generated for 'M_Ila_DDR' in directory
D:\Temp\M_Lcd4Top_0619\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * M_Ila_DDR.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * M_Ila_DDR.cdc
   * M_Ila_DDR.constraints/M_Ila_DDR.ucf
   * M_Ila_DDR.constraints/M_Ila_DDR.xdc
   * M_Ila_DDR.ncf
   * M_Ila_DDR.ngc
   * M_Ila_DDR.ucf
   * M_Ila_DDR.vhd
   * M_Ila_DDR.vho
   * M_Ila_DDR.xdc
   * M_Ila_DDR_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * M_Ila_DDR.asy

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * M_Ila_DDR.gise
   * M_Ila_DDR.xise
   * _xmsgs/pn_parser.xmsgs

Deliver Readme:
   Readme file for the IP.

   * M_Ila_DDR_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * M_Ila_DDR_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

