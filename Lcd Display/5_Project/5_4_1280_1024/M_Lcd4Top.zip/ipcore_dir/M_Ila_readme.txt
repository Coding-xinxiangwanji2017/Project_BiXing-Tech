The following files were generated for 'M_Ila' in directory
F:\My_wrok_2016\Hagongda\ise\M_Lcd4Top\ipcore_dir\

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * M_Ila.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * M_Ila.cdc
   * M_Ila.constraints/M_Ila.ucf
   * M_Ila.constraints/M_Ila.xdc
   * M_Ila.ncf
   * M_Ila.ngc
   * M_Ila.ucf
   * M_Ila.vhd
   * M_Ila.vho
   * M_Ila.xdc
   * M_Ila_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * M_Ila.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * M_Ila.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * M_Ila.gise
   * M_Ila.xise
   * _xmsgs/pn_parser.xmsgs

Deliver Readme:
   Readme file for the IP.

   * M_Ila_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * M_Ila_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

